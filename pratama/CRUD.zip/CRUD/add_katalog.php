<html>
<head>
	<title>Add Buku</title>
</head>

 <?php
include_once("connect.php");

// Cek apakah form telah disubmit
if (isset($_POST['submit'])) {
    // Ambil data dari form input
    $nama = mysqli_real_escape_string($mysqli, $_POST['nama']);

    $result = mysqli_query($mysqli, "INSERT INTO katalog(nama) VALUES('$nama')");

    if ($result) {
        echo "Data katalog berhasil ditambahkan.";
    } else {
        echo "Gagal menambahkan data. Error: " . mysqli_error($mysqli);
    }
}
?>

<body>
	<a href="index.php">Go to Home</a>
	<br/><br/>
 
	<form action="add_katalog.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Id Katalog</td>
				<td><input type="text" name="id_katalog"></td>
			</tr>
			<tr> 
				<td>Nama</td>
				<td><input type="text" name="nama"></td>
			</tr>

			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
	
	<?php
	 
		// Check If form submitted, insert form data into users table.
		if(isset($_POST['Submit'])) {
			$id_katalog = $_POST['id_katalog'];
			$nama = $_POST['nama'];
			
			include_once("connect.php");

			$result = mysqli_query($mysqli, "INSERT INTO `katalog` (`id_katalog`, `nama`) VALUES ('$id_katalog', '$nama');");

			
			header("Location:katalog.php");
		}
	?>


</body>
</html>