<?php
    include_once("connect.php");

    // Query untuk mengambil semua data pengarang beserta buku, penerbit, dan katalog
    $pengarang = mysqli_query($mysqli, "SELECT pengarang.*, 
       buku.judul, 
       penerbit.nama_penerbit, 
       katalog.nama AS nama_katalog
       FROM pengarang
        LEFT JOIN buku ON pengarang.id_pengarang = buku.id_pengarang
        LEFT JOIN penerbit ON penerbit.id_penerbit = buku.id_penerbit
        LEFT JOIN katalog ON katalog.id_katalog = buku.id_katalog
        ORDER BY pengarang.nama_pengarang ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha384-KyZXEAg3QhqLMpG8r+Knujsl5+5hb7xST17Xc6brUjbHjljW9lrL9V5M9Tq2aF7" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container mt-4">
        <center>
            <nav class="nav nav-pills nav-justified">
                <a class="nav-link" href="index.php">Buku</a>
                <a class="nav-link" href="penerbit.php">Penerbit</a>
                <a class="nav-link active" href="pengarang.php">Pengarang</a>
                <a class="nav-link" href="katalog.php">Katalog</a>
            </nav>
            <hr>
        </center>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Daftar Pengarang</h2>
            <a href="add_pengarang.php" class="btn btn-success">Add New Pengarang</a>
        </div>

        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>ID Pengarang</th>
                    <th>Nama Pengarang</th>
                    <th>Email</th>
                    <th>Telp</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php  
                    while($pengarang_data = mysqli_fetch_array($pengarang)) {         
                        echo "<tr>";
                        echo "<td>".$pengarang_data['id_pengarang']."</td>";
                        echo "<td>".$pengarang_data['nama_pengarang']."</td>";
                        echo "<td>".$pengarang_data['email']."</td>";        
                        echo "<td>".$pengarang_data['telp']."</td>";    
                        echo "<td>".$pengarang_data['alamat']."</td>";    
                        echo "<td>
                            <a class='btn btn-primary btn-sm' href='edit_pengarang.php?id_pengarang=$pengarang_data[id_pengarang]'>Edit</a> 
                            <a class='btn btn-danger btn-sm' href='delete_pengarang.php?id_pengarang=$pengarang_data[id_pengarang]'>Delete</a>
                        </td>";        
                        echo "</tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
