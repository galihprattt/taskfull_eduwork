<?php
$servername = "localhost";
$database = "perpus";
$username = "root";
$password = "";

// Create connection
$mysqli = mysqli_connect($servername, $username, $password, $database);

?>